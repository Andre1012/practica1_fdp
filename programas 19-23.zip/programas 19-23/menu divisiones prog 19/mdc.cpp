//Programa de un menu con submenu
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<ctype.h>
char opc,opc2,resp;
main()
{
	do
	{
	system("cls");	
	puts("DIVISIONES\n");
	puts("a) Division sur");
	puts("b) Division norte");
	puts("c) Division este");
	puts("d) Division oeste");
	printf("Elige una opcion\n");
	opc=getche();
	opc=tolower(opc);
	printf("\n");
	switch(opc)
	{
		case 'a':
			printf("VENDEDORES DE LA DIVISION SUR\n\n");
			puts("a) Ventas de Pedro");
	        puts("b) Ventas de David");
	        puts("c) Ventas de Mario");
           	printf("Elige una opcion\n");
	        opc2=getche();
	        opc2=tolower(opc2);
	        printf("\n");
	        switch(opc2)
	        {
	        	case 'a':
	        		printf("Las ventas de Pedro son: $5000\n");
	        		break;
	            case 'b':
	        		printf("Las ventas de David son: $1000\n");
	        		break;
	            case 'c':
	        		printf("Las ventas de Mario son: $5000\n");
					break;	  
				default:
	       	    printf("No existe la opcion\n");
		        break;
		   }
		   break;
		 case 'b':
			printf("VENDEDORES DE LA DIVISION NORTE\n\n");
			puts("a) Ventas de Marco");
	        puts("b) Ventas de Manuel");
	        puts("c) Ventas de Javier");
           	printf("Elige una opcion\n");
	        opc2=getche();
	        opc2=tolower(opc2);
	        printf("\n");
	        switch(opc2)
	        {
	        	case 'a':
	        		printf("Las ventas de Marco son: $304\n");
	        		break;
	            case 'b':
	        		printf("Las ventas de Manuel son: $4700\n");
	        		break;
	            case 'c':
	        		printf("Las ventas de Javier son: $6234\n");
					break;
				default:
	       	    printf("No existe la opcion\n");
		        break;		  	
		    }
		    break;
			case 'c':
			printf("VENDEDORES DE LA DIVISION ESTE\n\n");
			puts("a) Ventas de Brandon");
	        puts("b) Ventas de Alexis");
	        puts("c) Ventas de Arturo");
           	printf("Elige una opcion\n");
	        opc2=getche();
	        opc2=tolower(opc2);
	        printf("\n");
	        switch(opc2)
	        {
	        	case 'a':
	        		printf("Las ventas de Brandon son: $120\n");
	        		break;
	            case 'b':
	        		printf("Las ventas de Alexis son: $4700\n");
	        		break;
	            case 'c':
	        		printf("Las ventas de Arturo son: $6234\n");
					break;
				default:
	       	    printf("No existe la opcion\n");
		        break;	  	
		    } 
		    break;
		    case 'd':
			printf("VENDEDORES DE LA DIVISION OESTE\n\n");
			puts("a) Ventas de Agustin");
	        puts("b) Ventas de Oliver");
	        puts("c) Ventas de Carlos");
           	printf("Elige una opcion\n");
	        opc2=getche();
	        opc2=tolower(opc2);
	        printf("\n");
	        switch(opc2)
	        {
	        	case 'a':
	        		printf("Las ventas de Agustin son: $4231\n");
	        		break;
	            case 'b':
	        		printf("Las ventas de Oliver son: $8945\n");
	        		break;
	            case 'c':
	        		printf("Las ventas de Carlos son: $264\n");
					break;
				default:
	       	    printf("No existe la opcion\n");
		        break;	  	
		    }
		    break;
	default:
	printf("No existe la opcion\n\n");
	break;		     
	}
	printf("Deseas regresar al menu principal: (1) Si (0) No\n");
    resp=getche();
    }
    while (resp=='1');
    getch();
    return 0;
}
