//Programa de un menu con operaciones
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int num1,num2,opc,resp;
float res;
main()
{
	do
	{
	system("cls");
	printf("                                MENU OPERACIONES\n");
	printf("Escribe el valor del primer numero: ");
	scanf("%d",&num1);
	printf("Escribe el valor del segundo numero: ");
	scanf("%d",&num2);
	puts("\nElige la operacion a realizar");
	puts("1) Suma");
	puts("2) Resta");
	puts("3) Multiplicacion");
	puts("4) Division\n");
	scanf("%d",&opc);
	switch(opc)
	  {
		case 1:
			res=num1+num2;
			printf("La suma de: %d+%d= %.2f",num1,num2,res);
			break;
		case 2:
			res=num1-num2;
			printf("La resta de: %d-%d= %.2f",num1,num2,res);
			break;
		case 3:
			res=num1*num2;
			printf("La multiplicacion de: %d*%d= %.2f",num1,num2,res);
			break;
		case 4:
			res=(num1/num2);
			printf("La division de: (%d/%d)= %.2f",num1,num2,res);
			break;	
		default:
			printf("La opcion seleccionada no existe");
			break;
	  }
	printf("\n");  
	printf("Deseas regresar al menu principal: (1) Si (0) No\n");
    scanf("%d",&resp);
    }
    while(resp==1);
	getch();
	return 0;
}
