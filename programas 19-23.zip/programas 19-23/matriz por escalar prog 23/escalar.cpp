//Programa multiplicaci�n de arreglos por un escalar
#include<stdio.h>
#include<conio.h>
int tabla1[5][5],a,b;
float m,e;
main()
{
	printf("Escribe el valor del escalar\n");
	scanf("%f",&e);
	printf("Tabla 1\n");
	for(a=1;a<3;a++)
	{
	for(b=1;b<3;b++)
	  {
	  	printf("Dame el elemento [%d,%d] ",a,b);
	  	scanf("%d",&tabla1[a][b]);
	  	m=e*tabla1[a][b];
	  	printf("El valor de la posicion [%d,%d] multiplicada por el escalar es: %.2f\n",a,b,m);
	  }
    }
    getch();
    return 0;
}
