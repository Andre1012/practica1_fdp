//Programa suma arreglos
#include<stdio.h>
#include<conio.h>
int tabla1[5][5],a,b,tabla2[5][5],c,d,s,t,u,v;
main()
{
	printf("Tabla 1\n");
	for(a=1;a<3;a++)
	{
	for(b=1;b<3;b++)
	  {
	  	printf("Dame el elemento [%d,%d] ",a,b);
	  	scanf("%d",&tabla1[a][b]);
	  }
    }
    printf("\n");
    printf("Tabla 2\n");
    for(c=1;c<3;c++)
	{
	for(d=1;d<3;d++)
	  {
	  	printf("Dame el elemento [%d,%d] ",c,d);
	  	scanf("%d",&tabla2[c][d]);
	  }
    }
    s=(tabla1[1][1]+tabla2[1][1]);
    t=(tabla1[1][2]+tabla2[1][2]);
    u=(tabla1[2][1]+tabla2[2][1]);
    v=(tabla1[2][2]+tabla2[2][2]);
    
    printf("El resultado de la suma de las tablas [1,1] es: %d\n",s);
    printf("El resultado de la suma de las tablas [1,2] es: %d\n",t);
    printf("El resultado de la suma de las tablas [2,1] es: %d\n",u);
    printf("El resultado de la suma de las tablas [2,2] es: %d\n",v);
    getch();
    return 0;
}
