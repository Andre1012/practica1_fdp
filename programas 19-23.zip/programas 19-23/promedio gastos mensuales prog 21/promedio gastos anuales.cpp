//Programa promedio gastos mensuales de un a�o
#include<stdio.h>
#include<conio.h>
int mes[15],a;
float prom,d;
main()
{
	for(a=1;a<13;a++)
	{
		printf("Escribe los gastos del mes %d: ",a);
	    scanf("%d",&mes[a]);
	    d+=mes[a];
	}
	prom=d/12;
	printf("El promedio de los gastos es: %.2f",prom);
	getch();
	return 0;
}   
